package com.engineer4myanmar.ha;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void funOpen15(View v)
    {
    	WebView web1=(WebView)findViewById(R.id.web1);
    	web1.loadUrl("http://192.168.1.2/index15.php");
    	Toast.makeText(getApplicationContext(), "Port 15 is Opened", Toast.LENGTH_SHORT).show();
    }
    
    public void funClose15(View v)
    {
    	WebView web1=(WebView)findViewById(R.id.web1);
    	web1.loadUrl("http://192.168.1.2/index150.php");
    	Toast.makeText(getApplicationContext(), "Port 15 is Closed", Toast.LENGTH_SHORT).show();
    }
    
}
