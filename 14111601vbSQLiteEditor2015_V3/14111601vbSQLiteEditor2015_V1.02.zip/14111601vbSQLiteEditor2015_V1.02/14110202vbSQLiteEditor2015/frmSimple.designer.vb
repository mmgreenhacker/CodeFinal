﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSimple
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.ListBox4 = New System.Windows.Forms.ListBox()
        Me.ListBox5 = New System.Windows.Forms.ListBox()
        Me.ListBox6 = New System.Windows.Forms.ListBox()
        Me.btnReadDatabase = New System.Windows.Forms.Button()
        Me.btnLastTest = New System.Windows.Forms.Button()
        Me.btnChangeFileName = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.FolderBrowserDialog2 = New System.Windows.Forms.FolderBrowserDialog()
        Me.btnBrowseAndAdd = New System.Windows.Forms.Button()
        Me.txtAppend = New System.Windows.Forms.TextBox()
        Me.ListBox7 = New System.Windows.Forms.ListBox()
        Me.ListBox8 = New System.Windows.Forms.ListBox()
        Me.ListBox9 = New System.Windows.Forms.ListBox()
        Me.btnAppendFileName = New System.Windows.Forms.Button()
        Me.lstError = New System.Windows.Forms.ListBox()
        Me.picCadet = New System.Windows.Forms.PictureBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtPhotoAddress = New System.Windows.Forms.TextBox()
        Me.btnPhotoBrowse = New System.Windows.Forms.Button()
        CType(Me.picCadet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 18
        Me.ListBox1.Location = New System.Drawing.Point(13, 67)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(109, 130)
        Me.ListBox1.TabIndex = 7
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 18
        Me.ListBox2.Location = New System.Drawing.Point(146, 67)
        Me.ListBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(109, 130)
        Me.ListBox2.TabIndex = 8
        '
        'ListBox3
        '
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.ItemHeight = 18
        Me.ListBox3.Location = New System.Drawing.Point(279, 67)
        Me.ListBox3.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(109, 130)
        Me.ListBox3.TabIndex = 9
        '
        'ListBox4
        '
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.ItemHeight = 18
        Me.ListBox4.Location = New System.Drawing.Point(412, 67)
        Me.ListBox4.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(109, 130)
        Me.ListBox4.TabIndex = 10
        '
        'ListBox5
        '
        Me.ListBox5.FormattingEnabled = True
        Me.ListBox5.ItemHeight = 18
        Me.ListBox5.Location = New System.Drawing.Point(13, 217)
        Me.ListBox5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox5.Name = "ListBox5"
        Me.ListBox5.Size = New System.Drawing.Size(109, 130)
        Me.ListBox5.TabIndex = 11
        '
        'ListBox6
        '
        Me.ListBox6.FormattingEnabled = True
        Me.ListBox6.ItemHeight = 18
        Me.ListBox6.Location = New System.Drawing.Point(147, 217)
        Me.ListBox6.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox6.Name = "ListBox6"
        Me.ListBox6.Size = New System.Drawing.Size(109, 130)
        Me.ListBox6.TabIndex = 12
        '
        'btnReadDatabase
        '
        Me.btnReadDatabase.Location = New System.Drawing.Point(12, 391)
        Me.btnReadDatabase.Name = "btnReadDatabase"
        Me.btnReadDatabase.Size = New System.Drawing.Size(148, 45)
        Me.btnReadDatabase.TabIndex = 14
        Me.btnReadDatabase.Text = "Read Database"
        Me.btnReadDatabase.UseVisualStyleBackColor = True
        '
        'btnLastTest
        '
        Me.btnLastTest.Location = New System.Drawing.Point(180, 391)
        Me.btnLastTest.Name = "btnLastTest"
        Me.btnLastTest.Size = New System.Drawing.Size(148, 45)
        Me.btnLastTest.TabIndex = 15
        Me.btnLastTest.Text = "LastTest"
        Me.btnLastTest.UseVisualStyleBackColor = True
        '
        'btnChangeFileName
        '
        Me.btnChangeFileName.Location = New System.Drawing.Point(348, 391)
        Me.btnChangeFileName.Name = "btnChangeFileName"
        Me.btnChangeFileName.Size = New System.Drawing.Size(148, 45)
        Me.btnChangeFileName.TabIndex = 16
        Me.btnChangeFileName.Text = "Change file name"
        Me.btnChangeFileName.UseVisualStyleBackColor = True
        '
        'btnBrowseAndAdd
        '
        Me.btnBrowseAndAdd.Location = New System.Drawing.Point(516, 391)
        Me.btnBrowseAndAdd.Name = "btnBrowseAndAdd"
        Me.btnBrowseAndAdd.Size = New System.Drawing.Size(148, 45)
        Me.btnBrowseAndAdd.TabIndex = 18
        Me.btnBrowseAndAdd.Text = "Browse and Add Data"
        Me.btnBrowseAndAdd.UseVisualStyleBackColor = True
        '
        'txtAppend
        '
        Me.txtAppend.Location = New System.Drawing.Point(13, 354)
        Me.txtAppend.Multiline = True
        Me.txtAppend.Name = "txtAppend"
        Me.txtAppend.Size = New System.Drawing.Size(820, 29)
        Me.txtAppend.TabIndex = 19
        Me.txtAppend.Text = "-အေနာ္ရထာတပ္ရင္း-အမွတ္(၁)တပ္ခြဲ"
        '
        'ListBox7
        '
        Me.ListBox7.FormattingEnabled = True
        Me.ListBox7.ItemHeight = 18
        Me.ListBox7.Location = New System.Drawing.Point(279, 217)
        Me.ListBox7.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox7.Name = "ListBox7"
        Me.ListBox7.Size = New System.Drawing.Size(109, 130)
        Me.ListBox7.TabIndex = 20
        '
        'ListBox8
        '
        Me.ListBox8.FormattingEnabled = True
        Me.ListBox8.ItemHeight = 18
        Me.ListBox8.Location = New System.Drawing.Point(412, 217)
        Me.ListBox8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox8.Name = "ListBox8"
        Me.ListBox8.Size = New System.Drawing.Size(109, 130)
        Me.ListBox8.TabIndex = 21
        '
        'ListBox9
        '
        Me.ListBox9.FormattingEnabled = True
        Me.ListBox9.ItemHeight = 18
        Me.ListBox9.Location = New System.Drawing.Point(545, 217)
        Me.ListBox9.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ListBox9.Name = "ListBox9"
        Me.ListBox9.Size = New System.Drawing.Size(109, 130)
        Me.ListBox9.TabIndex = 22
        '
        'btnAppendFileName
        '
        Me.btnAppendFileName.Location = New System.Drawing.Point(684, 391)
        Me.btnAppendFileName.Name = "btnAppendFileName"
        Me.btnAppendFileName.Size = New System.Drawing.Size(148, 45)
        Me.btnAppendFileName.TabIndex = 24
        Me.btnAppendFileName.Text = "Append File Name"
        Me.btnAppendFileName.UseVisualStyleBackColor = True
        '
        'lstError
        '
        Me.lstError.FormattingEnabled = True
        Me.lstError.ItemHeight = 18
        Me.lstError.Location = New System.Drawing.Point(669, 67)
        Me.lstError.Name = "lstError"
        Me.lstError.Size = New System.Drawing.Size(164, 274)
        Me.lstError.TabIndex = 25
        '
        'picCadet
        '
        Me.picCadet.Location = New System.Drawing.Point(545, 67)
        Me.picCadet.Name = "picCadet"
        Me.picCadet.Size = New System.Drawing.Size(109, 130)
        Me.picCadet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCadet.TabIndex = 26
        Me.picCadet.TabStop = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(12, 443)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(820, 23)
        Me.ProgressBar1.TabIndex = 27
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(13, 31)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(375, 25)
        Me.txtSearch.TabIndex = 28
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(394, 31)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(127, 24)
        Me.btnSearch.TabIndex = 29
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(846, 24)
        Me.MenuStrip1.TabIndex = 30
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileInfoToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'FileInfoToolStripMenuItem
        '
        Me.FileInfoToolStripMenuItem.Name = "FileInfoToolStripMenuItem"
        Me.FileInfoToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.FileInfoToolStripMenuItem.Text = "File Info"
        '
        'txtPhotoAddress
        '
        Me.txtPhotoAddress.Location = New System.Drawing.Point(532, 31)
        Me.txtPhotoAddress.Name = "txtPhotoAddress"
        Me.txtPhotoAddress.Size = New System.Drawing.Size(236, 25)
        Me.txtPhotoAddress.TabIndex = 31
        Me.txtPhotoAddress.Text = "C:\Users\bluephoenix\Desktop\Plaky\Photo_2"
        '
        'btnPhotoBrowse
        '
        Me.btnPhotoBrowse.Location = New System.Drawing.Point(779, 30)
        Me.btnPhotoBrowse.Name = "btnPhotoBrowse"
        Me.btnPhotoBrowse.Size = New System.Drawing.Size(53, 24)
        Me.btnPhotoBrowse.TabIndex = 32
        Me.btnPhotoBrowse.Text = "Browse"
        Me.btnPhotoBrowse.UseVisualStyleBackColor = True
        '
        'frmSimple
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(846, 469)
        Me.Controls.Add(Me.btnPhotoBrowse)
        Me.Controls.Add(Me.txtPhotoAddress)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.picCadet)
        Me.Controls.Add(Me.lstError)
        Me.Controls.Add(Me.btnAppendFileName)
        Me.Controls.Add(Me.ListBox9)
        Me.Controls.Add(Me.ListBox8)
        Me.Controls.Add(Me.ListBox7)
        Me.Controls.Add(Me.txtAppend)
        Me.Controls.Add(Me.btnBrowseAndAdd)
        Me.Controls.Add(Me.btnChangeFileName)
        Me.Controls.Add(Me.btnLastTest)
        Me.Controls.Add(Me.btnReadDatabase)
        Me.Controls.Add(Me.ListBox6)
        Me.Controls.Add(Me.ListBox5)
        Me.Controls.Add(Me.ListBox4)
        Me.Controls.Add(Me.ListBox3)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Zawgyi-One", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmSimple"
        Me.Text = "Simple SQLite Example"
        CType(Me.picCadet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox5 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox6 As System.Windows.Forms.ListBox
    Friend WithEvents btnReadDatabase As System.Windows.Forms.Button
    Friend WithEvents btnLastTest As System.Windows.Forms.Button
    Friend WithEvents btnChangeFileName As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents FolderBrowserDialog2 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents btnBrowseAndAdd As System.Windows.Forms.Button
    Friend WithEvents txtAppend As System.Windows.Forms.TextBox
    Friend WithEvents ListBox7 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox8 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox9 As System.Windows.Forms.ListBox
    Friend WithEvents btnAppendFileName As System.Windows.Forms.Button
    Friend WithEvents lstError As System.Windows.Forms.ListBox
    Friend WithEvents picCadet As System.Windows.Forms.PictureBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents btnSearch As System.Windows.Forms.Button
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtPhotoAddress As System.Windows.Forms.TextBox
    Friend WithEvents btnPhotoBrowse As System.Windows.Forms.Button

End Class
