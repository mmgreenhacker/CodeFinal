﻿Imports System
Imports System.IO
Imports System.Security
Imports System.Security.Cryptography
Imports System.Net.Mail
Imports System.Collections.Generic
Imports System.Drawing
Imports System.Text
Imports System.Windows.Forms
Imports EncriptionLibrary


Public Class frmMain
    Inherits System.Windows.Forms.Form


    Private Sub btnMainExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMainExit.Click
        Application.Exit()
    End Sub
End Class

